package com.bobjo.mini.model.dto;

public class Food {

    private String foodName1;
    private String foodName2;
    private String foodName3;
    private String foodName4;
    private String foodName5;
    private String foodName6;
    private String foodName7;
    private String foodName8;
    private String foodName9;
    private String foodName10;
    private String foodName11;
    private String foodName12;
    private String foodName13;
    private String foodName14;
    private String foodName15;
    private String foodName16;
    private String foodName17;
    private String foodName18;
    private String foodName19;
    private String foodName20;
    private String foodName21;
    private String foodName22;
    private String foodName23;
    private String foodName24;
    private String foodName25;
    private String foodName26;
    private String foodName27;
    private String foodName28;
    private String foodName29;
    private String foodName30;

    public Food() {
    }

    public Food(String foodName1, String foodName2, String foodName3, String foodName4, String foodName5, String foodName6, String foodName7, String foodName8, String foodName9, String foodName10, String foodName11, String foodName12, String foodName13, String foodName14, String foodName15, String foodName16, String foodName17, String foodName18, String foodName19, String foodName20, String foodName21, String foodName22, String foodName23, String foodName24, String foodName25, String foodName26, String foodName27, String foodName28, String foodName29, String foodName30) {
        this.foodName1 = foodName1;
        this.foodName2 = foodName2;
        this.foodName3 = foodName3;
        this.foodName4 = foodName4;
        this.foodName5 = foodName5;
        this.foodName6 = foodName6;
        this.foodName7 = foodName7;
        this.foodName8 = foodName8;
        this.foodName9 = foodName9;
        this.foodName10 = foodName10;
        this.foodName11 = foodName11;
        this.foodName12 = foodName12;
        this.foodName13 = foodName13;
        this.foodName14 = foodName14;
        this.foodName15 = foodName15;
        this.foodName16 = foodName16;
        this.foodName17 = foodName17;
        this.foodName18 = foodName18;
        this.foodName19 = foodName19;
        this.foodName20 = foodName20;
        this.foodName21 = foodName21;
        this.foodName22 = foodName22;
        this.foodName23 = foodName23;
        this.foodName24 = foodName24;
        this.foodName25 = foodName25;
        this.foodName26 = foodName26;
        this.foodName27 = foodName27;
        this.foodName28 = foodName28;
        this.foodName29 = foodName29;
        this.foodName30 = foodName30;
    }

    @Override
    public String toString() {
        return
                "No.1='" + foodName1 + '\'' +
                ", No.2='" + foodName2 + '\'' +
                ", No.3='" + foodName3 + '\'' +
                ", No.4='" + foodName4 + '\'' +
                ", No.5='" + foodName5 + '\'' +
                ", No.6='" + foodName6 + '\'' +
                ", No.7='" + foodName7 + '\'' +
                ", No.8='" + foodName8 + '\'' +
                ", No.9='" + foodName9 + '\'' +
                ", No.10='" + foodName10 + '\'' +
                ", No.11='" + foodName11 + '\'' +
                ", No.12='" + foodName12 + '\'' +
                ", No.13='" + foodName13 + '\'' +
                ", No.14='" + foodName14 + '\'' +
                ", No.15='" + foodName15 + '\'' +
                ", No.16='" + foodName16 + '\'' +
                ", No.17='" + foodName17 + '\'' +
                ", No.18='" + foodName18 + '\'' +
                ", No.19='" + foodName19 + '\'' +
                ", No.20='" + foodName20 + '\'' +
                ", No.21='" + foodName21 + '\'' +
                ", No.22='" + foodName22 + '\'' +
                ", No.23='" + foodName23 + '\'' +
                ", No.24='" + foodName24 + '\'' +
                ", No.25='" + foodName25 + '\'' +
                ", No.26='" + foodName26 + '\'' +
                ", No.27='" + foodName27 + '\'' +
                ", No.28='" + foodName28 + '\'' +
                ", No.29='" + foodName29 + '\'' +
                ", No.30='" + foodName30 + '\'' ;
    }
}


