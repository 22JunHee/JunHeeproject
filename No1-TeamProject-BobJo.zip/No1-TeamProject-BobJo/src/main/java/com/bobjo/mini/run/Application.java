package com.bobjo.mini.run;

import com.bobjo.mini.view.FoodMenu;

public class Application {

    public static void main(String[] args) {
        FoodMenu fm = new FoodMenu();
        fm.mainmenu();






    }
}
